#!/bin/sh

#launch the Grammaphone.FM Uploader client in the Graphical User Mode
java -jar gfsync.jar -gui
